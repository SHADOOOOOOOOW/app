import { useEffect, useState } from "react"

function getTodayDate() {
  return new Date().toISOString().split("T")[0]
}

export default function TodoTracker() {
  const [tasks, setTasks] = useState([])
  const [input, setInput] = useState("")
  const [today, setToday] = useState(getTodayDate())

  useEffect(() => {
    const interval = setInterval(() => {
      const current = getTodayDate()
      if (current !== today) {
        setToday(current)
        setTasks((prev) =>
          prev.map((task) => ({ ...task, done: false }))
        )
      }
    }, 60 * 1000)
    return () => clearInterval(interval)
  }, [today])

  useEffect(() => {
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker
          .register('/service-worker.js')
          .then(() => console.log('Service Worker zarejestrowany'))
          .catch((err) => console.error('Błąd SW:', err))
      })
    }
  }, [])

  const addTask = () => {
    if (input.trim() === "") return
    setTasks([
      ...tasks,
      {
        id: Date.now(),
        name: input,
        count: 0,
        done: false,
        history: {},
      },
    ])
    setInput("")
  }

  const toggleTask = (id) => {
    setTasks((prev) =>
      prev.map((task) => {
        if (task.id !== id) return task
        const isDone = !task.done
        const updatedHistory = { ...task.history }
        if (isDone) {
          updatedHistory[today] = (updatedHistory[today] || 0) + 1
        }
        return {
          ...task,
          done: isDone,
          count: isDone ? task.count + 1 : task.count,
          history: updatedHistory,
        }
      })
    )
  }

  return (
    <div style={{ padding: "1rem", maxWidth: 400, margin: "auto" }}>
      <h1 style={{ fontSize: "1.5rem", textAlign: "center" }}>Codzienne Zadania</h1>
      <div style={{ display: "flex", gap: "0.5rem", marginBottom: "1rem" }}>
        <input
          placeholder="Nowe zadanie..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && addTask()}
          style={{ flexGrow: 1 }}
        />
        <button onClick={addTask}>Dodaj</button>
      </div>
      {tasks.map((task) => (
        <div key={task.id} style={{ border: "1px solid #ccc", borderRadius: 8, padding: "0.5rem", marginBottom: "0.5rem", display: "flex", justifyContent: "space-between" }}>
          <div>
            <input type="checkbox" checked={task.done} onChange={() => toggleTask(task.id)} />
            <span style={{ marginLeft: 8, textDecoration: task.done ? "line-through" : "none" }}>{task.name}</span>
          </div>
          <div style={{ textAlign: "right", fontSize: "0.8rem", color: "#666" }}>
            <div>Razem: {task.count}</div>
            <div>Dzisiaj: {task.history[today] || 0}</div>
          </div>
        </div>
      ))}
    </div>
  )
}
