self.addEventListener('install', (event) => {
  console.log('[SW] Service Worker zainstalowany')
})

self.addEventListener('fetch', (event) => {
  event.respondWith(
    fetch(event.request).catch(() => new Response('Offline', { status: 503 }))
  )
})
